/* School Face Attendance - privacy-first pilot.
   Camera frames are never uploaded. No face recognition is implemented in this version. */
(() => {
  const $ = (id) => document.getElementById(id);
  const cfgKey = "sfa_public_supabase_config";
  let client = null;
  let currentUser = null;
  let cameraStream = null;

  const setupCard = $("setupCard");
  const loginCard = $("loginCard");
  const appPanel = $("appPanel");

  function setMessage(id, message, type = "") {
    const el = $(id);
    el.textContent = message;
    el.className = "message" + (type ? " " + type : "");
  }
  function show(el, visible) { el.classList.toggle("hidden", !visible); }
  function safeText(value) {
    return String(value ?? "").replace(/[&<>"']/g, ch => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[ch]));
  }

  function loadConfig() {
    try {
      const config = JSON.parse(localStorage.getItem(cfgKey) || "null");
      if (!config?.url || !config?.key) return false;
      $("supabaseUrl").value = config.url;
      $("supabaseKey").value = config.key;
      client = window.supabase.createClient(config.url, config.key, {
        auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
      });
      show(setupCard, false);
      return true;
    } catch (error) {
      console.error(error);
      return false;
    }
  }

  async function initialize() {
    if (!client) {
      show(setupCard, true); show(loginCard, false); show(appPanel, false);
      return;
    }
    const { data: { session }, error } = await client.auth.getSession();
    if (error) console.error(error);
    if (session?.user) await enterWorkspace(session.user);
    else { show(loginCard, true); show(appPanel, false); }
  }

  async function enterWorkspace(user) {
    currentUser = user;
    const { data: profile, error } = await client
      .from("sfa_profiles").select("display_name, role").eq("id", user.id).maybeSingle();

    if (error || !profile) {
      await client.auth.signOut();
      currentUser = null;
      show(loginCard, true); show(appPanel, false);
      setMessage("loginMessage",
        "No staff profile found. Ask the Supabase project administrator to create your sfa_profiles row and assign the teacher or admin role.",
        "error");
      return;
    }
    if (!["admin", "teacher"].includes(profile.role)) {
      await client.auth.signOut();
      currentUser = null;
      setMessage("loginMessage", "This pilot workspace is for authorized school staff only.", "error");
      show(loginCard, true); show(appPanel, false);
      return;
    }
    $("staffInfo").textContent = `${profile.display_name || user.email} · ${profile.role}`;
    show(loginCard, false); show(appPanel, true); show($("logoutBtn"), true);
    await loadRecords();
  }

  $("configForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const url = $("supabaseUrl").value.trim().replace(/\/+$/, "");
    const key = $("supabaseKey").value.trim();
    if (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(url)) {
      alert("Enter the project URL in the format https://your-project.supabase.co");
      return;
    }
    if (!key) { alert("Enter the public anon/publishable key."); return; }
    localStorage.setItem(cfgKey, JSON.stringify({ url, key }));
    client = window.supabase.createClient(url, key, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
    });
    show(setupCard, false);
    await initialize();
  });

  $("loginForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    setMessage("loginMessage", "Signing in…");
    const email = $("email").value.trim();
    const password = $("password").value;
    const { data, error } = await client.auth.signInWithPassword({ email, password });
    if (error) {
      setMessage("loginMessage", error.message, "error");
      return;
    }
    setMessage("loginMessage", "");
    await enterWorkspace(data.user);
  });

  $("logoutBtn").addEventListener("click", async () => {
    await stopCamera();
    await client?.auth.signOut();
    currentUser = null;
    show(appPanel, false); show(loginCard, true); show($("logoutBtn"), false);
    setMessage("loginMessage", "You have signed out.", "success");
  });

  async function startCamera() {
    if (!navigator.mediaDevices?.getUserMedia) {
      setMessage("cameraMessage", "Camera access is unavailable. Open this page over HTTPS on your phone, or use localhost for computer testing.", "error");
      return;
    }
    try {
      cameraStream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: { facingMode: { ideal: "user" }, width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      $("cameraVideo").srcObject = cameraStream;
      $("cameraVideo").style.display = "block";
      $("cameraPlaceholder").classList.add("hidden");
      $("cameraStatus").textContent = "Camera on";
      $("startCameraBtn").disabled = true;
      $("stopCameraBtn").disabled = false;
      setMessage("cameraMessage", "Camera is running in this browser. No photo or video is being sent to Supabase.", "success");
    } catch (error) {
      setMessage("cameraMessage", `Could not start camera: ${error.message}. Check browser permission and that no other app is using it.`, "error");
    }
  }

  async function stopCamera() {
    if (cameraStream) cameraStream.getTracks().forEach(track => track.stop());
    cameraStream = null;
    $("cameraVideo").srcObject = null;
    $("cameraVideo").style.display = "none";
    $("cameraPlaceholder").classList.remove("hidden");
    $("cameraStatus").textContent = "Camera off";
    $("startCameraBtn").disabled = false;
    $("stopCameraBtn").disabled = true;
  }
  $("startCameraBtn").addEventListener("click", startCamera);
  $("stopCameraBtn").addEventListener("click", stopCamera);

  $("attendanceForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!client || !currentUser) return;
    const code = $("studentCode").value.trim();
    const status = $("attendanceStatus").value;
    if (!code) return;
    setMessage("attendanceMessage", "Checking student code…");
    const { data: student, error: findError } = await client
      .from("sfa_students")
      .select("id, student_code, full_name, class_name, active")
      .eq("student_code", code)
      .eq("active", true)
      .maybeSingle();

    if (findError || !student) {
      setMessage("attendanceMessage", findError?.message || "No active student found with that code.", "error");
      return;
    }
    const today = new Date();
    const localDate = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,"0")}-${String(today.getDate()).padStart(2,"0")}`;

    const { error: insertError } = await client.from("sfa_attendance").insert({
      student_id: student.id,
      attendance_date: localDate,
      status,
      marked_by: currentUser.id
    });
    if (insertError) {
      const message = insertError.code === "23505"
        ? "Attendance has already been recorded for this student today."
        : insertError.message;
      setMessage("attendanceMessage", message, "error");
      return;
    }
    setMessage("attendanceMessage", `Recorded ${status} for ${student.full_name} (${student.class_name || "class not set"}). Staff verification is required; this was not an automated face match.`, "success");
    $("studentCode").value = "";
    await loadRecords();
  });

  async function loadRecords() {
    if (!client) return;
    $("records").innerHTML = '<p class="muted">Loading records…</p>';
    const { data, error } = await client
      .from("sfa_attendance")
      .select("id, attendance_date, status, created_at, sfa_students(full_name, student_code, class_name)")
      .order("created_at", { ascending: false })
      .limit(20);

    if (error) {
      $("records").innerHTML = `<p class="message error">${safeText(error.message)}</p>`;
      return;
    }
    if (!data?.length) {
      $("records").innerHTML = '<p class="muted">No attendance records yet.</p>';
      return;
    }
    $("records").innerHTML = data.map(row => {
      const student = row.sfa_students || {};
      const time = row.created_at ? new Date(row.created_at).toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"}) : "";
      return `<div class="record">
        <div><strong>${safeText(student.full_name || "Student")}</strong>
        <small>${safeText(student.student_code || "")} · ${safeText(student.class_name || "Class not set")} · ${safeText(time)}</small></div>
        <span class="record-status">${safeText(row.status)}</span>
      </div>`;
    }).join("");
  }
  $("refreshBtn").addEventListener("click", loadRecords);

  loadConfig();
  initialize();
})(); 
