-- School Face Attendance (SFA) pilot schema.
-- Uses separate sfa_ table names so it does not overwrite tables in an existing project.
-- Run in Supabase SQL Editor. Create staff users in Authentication first.

create table if not exists public.sfa_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  role text not null check (role in ('admin', 'teacher', 'parent', 'student')),
  created_at timestamptz not null default now()
);

create table if not exists public.sfa_students (
  id uuid primary key default gen_random_uuid(),
  student_code text not null unique,
  full_name text not null,
  class_name text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.sfa_attendance (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.sfa_students(id) on delete restrict,
  attendance_date date not null default (now() at time zone 'Asia/Kuala_Lumpur')::date,
  status text not null check (status in ('present', 'late')),
  marked_by uuid not null references public.sfa_profiles(id) on delete restrict,
  created_at timestamptz not null default now(),
  unique (student_id, attendance_date)
);

create index if not exists sfa_attendance_date_idx
  on public.sfa_attendance (attendance_date desc);
create index if not exists sfa_attendance_student_idx
  on public.sfa_attendance (student_id);

-- Helper avoids repeating profile-role lookup logic in policies.
create or replace function public.sfa_current_role()
returns text
language sql
stable
security definer
set search_path = ''
as $$
  select p.role
  from public.sfa_profiles p
  where p.id = auth.uid()
  limit 1;
$$;

revoke all on function public.sfa_current_role() from public;
grant execute on function public.sfa_current_role() to authenticated;

alter table public.sfa_profiles enable row level security;
alter table public.sfa_students enable row level security;
alter table public.sfa_attendance enable row level security;

drop policy if exists "sfa profile read own or staff" on public.sfa_profiles;
create policy "sfa profile read own or staff"
on public.sfa_profiles for select to authenticated
using (
  id = auth.uid()
  or public.sfa_current_role() in ('admin', 'teacher')
);

drop policy if exists "sfa admin manage profiles" on public.sfa_profiles;
create policy "sfa admin manage profiles"
on public.sfa_profiles for all to authenticated
using (public.sfa_current_role() = 'admin')
with check (public.sfa_current_role() = 'admin');

drop policy if exists "sfa staff read students" on public.sfa_students;
create policy "sfa staff read students"
on public.sfa_students for select to authenticated
using (public.sfa_current_role() in ('admin', 'teacher'));

drop policy if exists "sfa admin manage students" on public.sfa_students;
create policy "sfa admin manage students"
on public.sfa_students for all to authenticated
using (public.sfa_current_role() = 'admin')
with check (public.sfa_current_role() = 'admin');

drop policy if exists "sfa staff read attendance" on public.sfa_attendance;
create policy "sfa staff read attendance"
on public.sfa_attendance for select to authenticated
using (public.sfa_current_role() in ('admin', 'teacher'));

drop policy if exists "sfa staff record attendance" on public.sfa_attendance;
create policy "sfa staff record attendance"
on public.sfa_attendance for insert to authenticated
with check (
  public.sfa_current_role() in ('admin', 'teacher')
  and marked_by = auth.uid()
);

drop policy if exists "sfa admin update attendance" on public.sfa_attendance;
create policy "sfa admin update attendance"
on public.sfa_attendance for update to authenticated
using (public.sfa_current_role() = 'admin')
with check (public.sfa_current_role() = 'admin');

-- Limit direct table permissions; RLS still applies.
grant usage on schema public to authenticated;
grant select on public.sfa_profiles to authenticated;
grant select, insert, update, delete on public.sfa_students to authenticated;
grant select, insert, update on public.sfa_attendance to authenticated;

-- IMPORTANT:
-- 1. Add a student only after you have school authorization.
-- 2. Do not store face images, face embeddings, or biometric templates in these tables.
-- 3. Create each staff auth user in Authentication, then insert a matching sfa_profiles row.
-- 4. Parent/student self-service policies are not included in this pilot.
